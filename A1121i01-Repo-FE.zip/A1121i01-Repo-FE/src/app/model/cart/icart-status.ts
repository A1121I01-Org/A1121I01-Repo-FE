export interface ICartStatus {
  cartStatusId?: number;
  cartStatusName?: string;
  cartStatusFlag?: boolean;
}
