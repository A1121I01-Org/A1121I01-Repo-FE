export interface Wards {
  name?: string;
  code?: string;
  codename?: string;
  division_type?: string;
  short_codename?: string;
}
