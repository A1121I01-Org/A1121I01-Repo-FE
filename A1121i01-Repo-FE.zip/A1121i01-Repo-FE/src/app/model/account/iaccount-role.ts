export interface IAccountRole {
  accountRoleId?: number;
  accountRoleFlag?: boolean;
  accountId?: number;
  roleId?: number;
}
