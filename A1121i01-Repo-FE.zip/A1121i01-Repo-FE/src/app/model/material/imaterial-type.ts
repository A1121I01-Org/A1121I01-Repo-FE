export interface IMaterialType {
  materialTypeId?: number;
  materialTypeName?: string;
  materialTypeFlag?: boolean;
}
