import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sell-cart',
  templateUrl: './sell-cart.component.html',
  styleUrls: ['./sell-cart.component.css']
})
export class SellCartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
}
